exports.handler = async (event) => {
  const headers = { "Content-Type": "application/json" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({error:"Только POST"}) };
  const token = process.env.HF_TOKEN;
  if (!token) return { statusCode: 500, headers, body: JSON.stringify({error:"На Netlify не задан HF_TOKEN"}) };
  try {
    const ct = event.headers["content-type"] || event.headers["Content-Type"] || "";
    const boundary = (ct.match(/boundary=(?:"([^"]+)"|([^;]+))/i) || []).slice(1).find(Boolean);
    if (!boundary || !event.body) throw Error("Не удалось прочитать фото");
    const raw = Buffer.from(event.body, event.isBase64Encoded ? "base64" : "utf8");
    const text = raw.toString("latin1");
    const part = text.split("--" + boundary).find(p => /name="image"/i.test(p));
    if (!part) throw Error("Фотография не найдена");
    const split = part.indexOf("\r\n\r\n");
    const head = part.slice(0, split);
    const mime = ((head.match(/Content-Type:\s*([^\r\n]+)/i)||[])[1]||"image/jpeg").trim();
    if (!/^image\/(jpeg|png|webp)$/i.test(mime)) throw Error("Нужен JPG, PNG или WEBP");
    const payload = part.slice(split+4).replace(/\r\n$/, "");
    const bytes = Buffer.from(payload, "latin1");
    if (bytes.length > 5*1024*1024) throw Error("Фото должно быть меньше 5 МБ");
    const upstream = await fetch("https://router.huggingface.co/hf-inference/models/google/vit-base-patch16-224", {
      method:"POST", headers:{"Authorization":"Bearer "+token,"Content-Type":mime}, body:bytes
    });
    const rawResult = await upstream.text();
    if (!upstream.ok) throw Error("AI-провайдер вернул ошибку "+upstream.status+". Проверь токен и доступность модели.");
    const parsed = JSON.parse(rawResult);
    const labels = Array.isArray(parsed) ? parsed.slice(0,5).map(x=>({label:String(x.label||"Unknown"),score:Number(x.score||0)})) : [];
    return {statusCode:200,headers,body:JSON.stringify({labels})};
  } catch(e) { return {statusCode:500,headers,body:JSON.stringify({error:e.message||"Ошибка сервера"})}; }
};